function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6b0Qm6X7e1w":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

